package domain;
/**
 * Tipo que representa os possiveis estados de um elemento
 * num espaco em processo de simulacao
 * @author isabel nunes
 * @date Novembro 2020
 */
public enum EstadoSimulacao {
	LIVRE, AFETADO, OBSTACULO;
}
