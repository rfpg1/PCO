package domain;
/**
 * Tipo que representa os possiveis niveis de perigo de fogo
 * @author isabel nunes
 */
public enum NivelPerigo {
	VERDE, AMARELO, LARANJA, VERMELHO;
}
