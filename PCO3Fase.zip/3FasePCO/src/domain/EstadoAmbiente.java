package domain;
/**
 * Tipo que representa os possiveis elementos do espaco de uma
 * regiao
 * @author isabel nunes
 * @date Novembro 2020
*/
public enum EstadoAmbiente {
	CASA, TERRENO, ESTRADA, AGUA, ARDIDO;
}
