package domain;

public interface Acionavel {
	public EstadoSimulacao[][] alvoSimulacao();
	public boolean podeAtuar();
}
